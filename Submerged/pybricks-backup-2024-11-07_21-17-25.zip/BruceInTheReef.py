from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

def Brucey(dbase:DriveBase, sbam:Motor, pam:Motor):
    dbase.settings(300, 700,250,500)
    pam.run_until_stalled(-100)
    pam.run_angle(130,98, wait=False)
    dbase.straight(860)
    dbase.turn(-56)
    dbase.straight(60)
    dbase.straight(-180)
    dbase.turn(-33)
    dbase.straight(100)
    pam.run_angle(105,25)
    dbase.curve(-225,-50)
    dbase.turn(40)
    dbase.straight(-70)
    pam.run_angle(105,-12)
    dbase.straight(85)
    pam.run_angle(105,-17)
    dbase.straight(-55)
    pam.run_angle(105,-15)
    dbase.straight(66)
    pam.run_until_stalled(-1000)
    dbase.turn(45)
    dbase.straight(-1000)
    #This code is KILLING me, MENTALLY.
